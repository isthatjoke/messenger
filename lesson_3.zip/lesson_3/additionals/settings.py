
DEFAULT_PORT = 9035
DEFAULT_IP = '127.0.0.1'
PACK_CAPACITY = 1024     #max message length in bytes
MAX_CONNECTIONS = 3      #max client connections
ENCODING = 'utf-8'















