a = {'integer': 1}

print(a)
a.pop('integer')
print(a)