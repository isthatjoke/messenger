
class IncorrectData:

    def __str__(self):
        return 'received incorrect data'


class IncorrectType:

    def __str__(self):
        return 'incorrect type'


class IncorrectDataToDecode:

    def __str__(self):
        return 'incorrect data to decode. must be bytes'

