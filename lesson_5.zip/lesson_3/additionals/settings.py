import logging

DEFAULT_PORT = 9035
DEFAULT_IP = '127.0.0.1'
PACK_CAPACITY = 1024     #max message length in bytes
MAX_CONNECTIONS = 3      #max client connections
ENCODING = 'utf-8'

# logging

LOGGING_LEVEL = logging.DEBUG



# JIM

ACTION = 'action'
PRESENCE = 'presence'
TIME = 'time'
ACCOUNT_NAME = 'account_name'
USER = 'user'
RESPONSE = 'response'
ERROR = 'ERROR'


# responses

RESPONSE_200 = {'response': 200}
RESPONSE_400 = {'response': 400, 'ERROR': 'Bad Request'}












